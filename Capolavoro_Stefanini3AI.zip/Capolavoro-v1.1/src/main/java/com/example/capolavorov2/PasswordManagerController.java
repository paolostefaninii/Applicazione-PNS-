package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class PasswordManagerController {
    private Stage stage;
    private PasswordManager passwordManager = DatiCondivisi.getPasswordManager();
    @FXML
    private Label elimNomeUtenteLabel;
    @FXML
    private Label elimPasswordLabel;
    @FXML
    private Label elimServizioLabel;
    @FXML
    private TextField elimNomeUtenteField;
    @FXML
    private TextField elimServizioField;
    @FXML
    private PasswordField elimPasswordField;
    @FXML
    private Button confermaButton;
    @FXML
    private Label statusElimPasswordLabel;
    @FXML
    private TextArea listaPasswordTextArea;
    @FXML
    private Button aggPasswordButton;
    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }
    @FXML
    public void initialize(){
        listaPasswordTextArea.setStyle("-fx-font-family: 'monospaced'");
        elimPasswordField.setOpacity(0);
        elimNomeUtenteField.setOpacity(0);
        elimPasswordLabel.setOpacity(0);
        elimServizioField.setOpacity(0);
        elimNomeUtenteLabel.setOpacity(0);
        elimServizioLabel.setOpacity(0);
        confermaButton.setOpacity(0);
        statusElimPasswordLabel.setOpacity(0);
        listaPasswordTextArea.setText(passwordManager.toString());
        aggPasswordButton.setOpacity(100);
        aggPasswordButton.setDisable(false);
        elimPasswordField.setDisable(true);
        elimNomeUtenteField.setDisable(true);
        elimPasswordLabel.setDisable(true);
        elimServizioField.setDisable(true);
        elimNomeUtenteLabel.setDisable(true);
        elimServizioLabel.setDisable(true);
        statusElimPasswordLabel.setDisable(true);
        confermaButton.setDisable(true);
    }
    @FXML
    public void rimPassword(ActionEvent actionEvent) {
        aggPasswordButton.setOpacity(0);
        aggPasswordButton.setDisable(true);
        elimPasswordField.setOpacity(100);
        elimNomeUtenteField.setOpacity(100);
        elimPasswordLabel.setOpacity(100);
        elimServizioField.setOpacity(100);
        elimNomeUtenteLabel.setOpacity(100);
        elimServizioLabel.setOpacity(100);
        confermaButton.setOpacity(100);
        statusElimPasswordLabel.setOpacity(100);
        elimPasswordField.setDisable(false);
        elimNomeUtenteField.setDisable(false);
        elimPasswordLabel.setDisable(false);
        elimServizioField.setDisable(false);
        elimNomeUtenteLabel.setDisable(false);
        elimServizioLabel.setDisable(false);
        statusElimPasswordLabel.setDisable(false);
        confermaButton.setDisable(false);
    }

    @FXML
    public void aggPassword(ActionEvent actionEvent) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/AggiungiPasswordMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void confermaEliminazionePassword(ActionEvent actionEvent) throws IOException {
        String nomeUtente = elimNomeUtenteField.getText();
        String password = elimPasswordField.getText();
        String servizio = elimServizioField.getText();
        passwordManager.rimuoviPassword(nomeUtente,password,servizio);
        initialize();
    }
}

package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class VisCompitiController {
    private Stage stage;
    private ToDoList toDoList = DatiCondivisi.getToDoList();
    @FXML
    private Button confermaButton;
    @FXML
    private TextField numCompitoTextField;
    @FXML
    private Label numCompitoLabel;
    @FXML
    private TextArea listaCompitiTextArea;

    public VisCompitiController() throws IOException {
    }

    @FXML
    public void initialize(){
        confermaButton.setOpacity(0);
        confermaButton.setDisable(true);
        numCompitoTextField.setOpacity(0);
        numCompitoTextField.setDisable(true);
        numCompitoLabel.setOpacity(0);
        listaCompitiTextArea.setText(toDoList.infoCompiti());
        listaCompitiTextArea.setStyle("-fx-font-family: 'monospaced'");
        numCompitoTextField.setText("");
    }

    @FXML
    public void rimCompito(ActionEvent actionEvent) {
        confermaButton.setOpacity(100);
        confermaButton.setDisable(false);
        numCompitoTextField.setDisable(false);
        numCompitoTextField.setOpacity(100);
        numCompitoLabel.setOpacity(100);
    }

    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void confermaEliminazioneCompito(ActionEvent actionEvent) throws IOException{
        String s = numCompitoTextField.getText();
        int n;
        if (!(s.equals(""))){
             n = Integer.parseInt(numCompitoTextField.getText());
            toDoList.eliminaCompito(n);
            initialize();
        }
    }
}

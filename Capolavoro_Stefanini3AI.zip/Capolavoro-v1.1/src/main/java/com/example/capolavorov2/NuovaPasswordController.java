package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class NuovaPasswordController {
    private Stage stage;
    private PasswordManager passwordManager = DatiCondivisi.getPasswordManager();
    @FXML
    private Label statusNewPasswordLabel;
    @FXML
    private TextField newNomeUtenteField;
    @FXML
    private PasswordField newPasswordField;
    @FXML
    private PasswordField confermaNewPasswordField;
    @FXML
    private TextField newNomeServizioField;
    @FXML
    public void initialize(){
        statusNewPasswordLabel.setOpacity(0);
    }
    @FXML
    public void creaPassword(ActionEvent actionEvent) throws IOException{
        String nomeUtente = newNomeUtenteField.getText();
        String password = newPasswordField.getText();
        String confermaPassword = confermaNewPasswordField.getText();
        String servizio = newNomeServizioField.getText();
        if (!(password.equals(confermaPassword))){
            statusNewPasswordLabel.setText("STATUS: Le due password non combaciano");
            statusNewPasswordLabel.setStyle("-fx-text-fill: red");
            statusNewPasswordLabel.setOpacity(100);
            newPasswordField.setText("");
            confermaNewPasswordField.setText("");
        }else{
            passwordManager.aggiungiPassword(nomeUtente,password,servizio);
            statusNewPasswordLabel.setText("Password creata con successo!");
            statusNewPasswordLabel.setStyle("-fx-text-fill: green");
            statusNewPasswordLabel.setOpacity(100);
            newNomeUtenteField.setText("");
            newPasswordField.setText("");
            confermaNewPasswordField.setText("");
            newNomeServizioField.setText("");
        }
    }
    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }
}

package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class ChatbotController {
    private Stage stage;
    private Chatbot chatbot = DatiCondivisi.getChatbot();

    @FXML
    private TextField insKeywordField;
    @FXML
    private Button inviaButton;
    @FXML
    private TextArea rispostaField;
    @FXML
    private Button aggKeywordButton;
    @FXML
    private TextField aggKeywordField;
    @FXML
    private TextArea aggDefField;
    @FXML
    private Button confermaButton;
    @FXML
    private Label keywordLabel;
    @FXML
    private Label defLabel;
    @FXML
    private Label statusLabel;

    @FXML
    public void initialize(){
        insKeywordField.setText("");
        rispostaField.setText("");
        aggDefField.setText("");
        aggKeywordField.setText("");
        aggKeywordButton.setDisable(true);
        aggKeywordField.setOpacity(0);
        aggKeywordField.setDisable(true);
        aggDefField.setOpacity(0);
        aggDefField.setDisable(true);
        confermaButton.setOpacity(0);
        confermaButton.setDisable(true);
        keywordLabel.setOpacity(0);
        defLabel.setOpacity(0);
        statusLabel.setOpacity(0);
    }

    @FXML
    public void cercaRisposte(ActionEvent actionEvent) throws IOException {
        String s = insKeywordField.getText();
        if (!(s.equals(""))){
            String ris = chatbot.rispondi(s);
            rispostaField.setText(chatbot.rispondi(s));
            if (ris.equals("Non ho risposte per questa keyword....Se vuoi puoi aggiungerla qui sotto")){
                aggKeywordButton.setDisable(false);
            }
        }
    }

    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void aggKeyword(ActionEvent actionEvent) {
        aggKeywordField.setOpacity(100);
        aggKeywordField.setDisable(false);
        aggDefField.setOpacity(100);
        aggDefField.setDisable(false);
        confermaButton.setOpacity(100);
        confermaButton.setDisable(false);
        keywordLabel.setOpacity(100);
        defLabel.setOpacity(100);
    }

    @FXML
    public void confermaNuovaKeyword(ActionEvent actionEvent) throws IOException {
        String keyword = aggKeywordField.getText();
        String def = aggDefField.getText();
        if (keyword.equals("")||def.equals("")){
            statusLabel.setOpacity(100);
        }else{
            chatbot.aggiungiDefininizione(keyword,def);
            initialize();
        }

    }
}

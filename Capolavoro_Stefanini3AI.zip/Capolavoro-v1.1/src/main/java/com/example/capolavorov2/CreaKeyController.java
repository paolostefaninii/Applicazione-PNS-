package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class CreaKeyController {
    private Stage stage;
    @FXML
    private PasswordField creaKeyField;
    @FXML
    private Label statusLabel;
    @FXML
    public void initializer(){
        statusLabel.setOpacity(0);
        statusLabel.setText("Completare il campo vuoto");
    }
    public CreaKeyController() throws IOException {
    }
    @FXML
    public void initialize(){
        statusLabel.setOpacity(0);
    }
    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void creaKey(ActionEvent actionEvent) throws IOException{
        String key = creaKeyField.getText();
        if (key.equals("")){
            statusLabel.setOpacity(100);
            statusLabel.setText("STATUS: Completare il campo vuoto");
        }else{
            PasswordManager passwordManager = DatiCondivisi.getPasswordManager();
            passwordManager.creaKeyAccesso(key);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
            Pane newScene = loader.load();
            Scene scene = new Scene(newScene);
            Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
        }

    }
}

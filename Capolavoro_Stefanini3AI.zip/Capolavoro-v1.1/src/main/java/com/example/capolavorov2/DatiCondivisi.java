package com.example.capolavorov2;

import java.io.IOException;

public class DatiCondivisi {
    private static final PasswordManager passwordManager;
    private static final ToDoList toDoList = new ToDoList();
    private static final Chatbot chatbot = new Chatbot();

    static {
        try {
            passwordManager = new PasswordManager();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static PasswordManager getPasswordManager() {
        return passwordManager;
    }

    public static ToDoList getToDoList() throws IOException {
        toDoList.caricaDaFile();
        return toDoList;
    }

    public static Chatbot getChatbot (){
        return chatbot;
    }
}
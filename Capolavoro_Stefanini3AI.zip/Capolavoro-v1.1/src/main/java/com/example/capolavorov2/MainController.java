package com.example.capolavorov2;

import com.sun.javafx.stage.EmbeddedWindow;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class MainController {
    private Stage stage;



    public MainController() throws IOException {
    }

    @FXML
    public void switchPasswordManager(ActionEvent actionEvent) throws IOException {
        PasswordManager passwordManager = DatiCondivisi.getPasswordManager();
        if (passwordManager.keyCreata()){
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/VerificaKeyPasswordManagerMenu.fxml"));
            Pane newScene = loader.load();
            Scene scene = new Scene(newScene);
            Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
        }else{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/CreaKeyMenu.fxml"));
            Pane newScene = loader.load();
            Scene scene = new Scene(newScene);
            Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
        }
    }

    @FXML
    public void switchToDoList(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/ToDoListMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void switchChatbot(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/ChatbotMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }
}
package com.example.capolavorov2;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ToDoList {
        File fileToDoList;
        private ArrayList<Compito> compiti;

        public ToDoList(){
            compiti = new ArrayList<Compito>();
            fileToDoList = new File("fileToDoList.txt");
        }

        public void aggiungiCompito(Compito compito) throws IOException{
            compiti.add(compito);
            salvaSuFile();
        }

        public void eliminaCompito(int num) throws IOException {
            caricaDaFile();
            if (num >= 1 && num <= compiti.size()) {
                compiti.remove(num - 1);
                salvaSuFile();
            }
        }

        public void salvaSuFile() throws IOException {
            FileWriter writer = new FileWriter("fileToDoList.txt",false);
            for (int i=0;i<compiti.size();i++){
                 writer.append((i+1)+";"+compiti.get(i).salvaInfoFile()+"\n");
            }
            writer.close();
        }

        public void caricaDaFile() throws IOException {
            compiti.clear();
            BufferedReader reader = new BufferedReader(new FileReader("fileToDoList.txt"));
            String riga;
            while ((riga = reader.readLine()) != null){
                String[] parti = riga.split(";");
                Compito c = new Compito(parti[1],parti[2],parti[3],parti[4]);
                compiti.add(c);
            }
            reader.close();
        }

    public ArrayList<Compito> getTreCompitiPiuUrgenti() throws IOException {
            caricaDaFile();
            ArrayList<Compito> ordinati = new ArrayList<>(compiti);

        for (int i = 0; i < ordinati.size() - 1; i++) {
            for (int j = i + 1; j < ordinati.size(); j++) {
                if (ordinati.get(i).giorniScadenza() > ordinati.get(j).giorniScadenza()) {
                    Compito temp = ordinati.get(i);
                    ordinati.set(i, ordinati.get(j));
                    ordinati.set(j, temp);
                }
            }
        }

        ArrayList<Compito> treCompiti = new ArrayList<>();
        for (int i = 0; i < 3 && i < ordinati.size(); i++) {
            treCompiti.add(ordinati.get(i));
        }

        return treCompiti;
    }

    public ArrayList<Compito> getCompiti(){
        return compiti;
    }

    public String infoCompiti(){
        BufferedReader reader = null;
        String s = "";
        try {
            reader = new BufferedReader(new FileReader("fileToDoList.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        String riga;
        s += String.format("%-10s %-20s %-80s %-25s %-15s\n", "NUM","NOME", "DESCRIZIONE", "DATA SCADENZA","PRIORITA'");
        while (true){
            try {
                if (!((riga = reader.readLine())!= null)) break;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            String[] parti = riga.split(";");
            s += String.format("%-10s %-20s %-80s %-25s %-15s\n", parti[0], parti[1], parti[2],parti[3],parti[4]);
        }
        try {
            reader.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return s;
    }
}
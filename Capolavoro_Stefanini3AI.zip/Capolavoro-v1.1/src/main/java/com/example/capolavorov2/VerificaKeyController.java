package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class VerificaKeyController {
    private Stage stage;
    @FXML
    private PasswordField insKeyField;
    @FXML
    private Label statusAccessoLabel;
    @FXML
    public void initialize(){
        statusAccessoLabel.setOpacity(0);
    }
    @FXML
    public void verificaKey(ActionEvent actionEvent) throws IOException{
        PasswordManager passwordManager = DatiCondivisi.getPasswordManager();
        String keyIns = insKeyField.getText();
        if (passwordManager.verificaChiave(keyIns)){
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/PasswordManagerMenu.fxml"));
            Pane newScene = loader.load();
            Scene scene = new Scene(newScene);
            Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
        }else{
            statusAccessoLabel.setText("Key errata....Riprovare");
            statusAccessoLabel.setOpacity(100);
        }
    }
    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }
}

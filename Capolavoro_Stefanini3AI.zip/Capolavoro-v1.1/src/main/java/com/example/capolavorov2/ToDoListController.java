package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class ToDoListController {
    private Stage stage;
    private ToDoList toDoList = DatiCondivisi.getToDoList();
    @FXML
    private TextArea compitiScadTextArea1;
    @FXML
    private TextArea compitiScadTextArea2;
    @FXML
    private TextArea compitiScadTextArea3;

    public ToDoListController() throws IOException {
    }

    @FXML
    public void initialize() throws IOException {
        int s = toDoList.getCompiti().size();
        switch (s){
            case 0:
                compitiScadTextArea1.setText("Inserisci compiti per vedere info");
                compitiScadTextArea2.setOpacity(0);
                compitiScadTextArea3.setOpacity(0);
                break;
            case 1:
                compitiScadTextArea1.setText(toDoList.getCompiti().get(0).toString());
                compitiScadTextArea2.setOpacity(0);
                compitiScadTextArea3.setOpacity(0);
                break;
            case 2:
                compitiScadTextArea1.setText(toDoList.getCompiti().get(0).toString());
                compitiScadTextArea2.setText(toDoList.getCompiti().get(1).toString());
                compitiScadTextArea3.setOpacity(0);
                break;
            default:
                ArrayList<Compito> treCompiti = toDoList.getTreCompitiPiuUrgenti();
                compitiScadTextArea1.setText(treCompiti.get(0).toString());
                compitiScadTextArea2.setText(treCompiti.get(1).toString());
                compitiScadTextArea3.setText(treCompiti.get(2).toString());
                break;
        }
    }
    public void switchVisCompiti(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/VisCompitiMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void switchAggCompito(ActionEvent actionEvent) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/CreaCompitoMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }

    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }
}

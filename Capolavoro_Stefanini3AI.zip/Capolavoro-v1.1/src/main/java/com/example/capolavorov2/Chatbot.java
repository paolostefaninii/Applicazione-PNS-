package com.example.capolavorov2;

import java.io.*;

public class Chatbot {
    File keywords = new File("fileKeywords.txt");

    public String rispondi(String input) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("fileKeywords.txt"));
        String riga;
        boolean trovato = false;
        while ((riga = reader.readLine()) != null && !trovato){
            String[] parti = riga.split(";");
            input = input.toUpperCase();
            if (input.contains(parti[0])){
                trovato = true;
                reader.close();
                return parti[1];
            }
        }
        if (!trovato){
            return "Non ho risposte per questa keyword....Se vuoi puoi aggiungerla qui sotto";
        }
        return "-1";
    }

    public void aggiungiDefininizione(String keyword, String def) throws IOException {
        FileWriter writer = new FileWriter("fileKeywords.txt",true);
        keyword = keyword.toUpperCase();
        writer.append(keyword+";"+def+"\n");
        writer.close();
    }
}

package com.example.capolavorov2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Compito {
    private String nome;
    private String descrizione;
    private String dataScadenza;
    private String priorita;
    LocalDate today = LocalDate.now();
    DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public Compito(String nome, String descrizione, String dataScadenza,String priorita) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.dataScadenza = dataScadenza;
        this.priorita = priorita;
    }

    public Compito(){
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public void setDataScadenza(String dataScadenza) {
        this.dataScadenza = dataScadenza;
    }

    public void setPriorita(String priorita) {
        this.priorita = priorita;
    }

    @Override
    public String toString() {
        return "NOME = " + nome + "\n\n" +
                "DESCRIZIONE = " + descrizione + "\n\n" +
                "DATA DI SCADENZA = " + dataScadenza + "\n\n" +
                "LIVELLO DI PRIORITA' = " + priorita + "\n\n";
    }

    public String salvaInfoFile(){
        return nome+";"+descrizione+";"+dataScadenza+";"+priorita;
    }

    public int giorniScadenza(){
        LocalDate dataScad = LocalDate.parse(dataScadenza,format);
        return (int)(ChronoUnit.DAYS.between(today,dataScad));
    }

    public String getNome() {
        return nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public String getDataScadenza() {
        return dataScadenza;
    }

    public String getPriorita() {
        return priorita;
    }
}

package com.example.capolavorov2;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PasswordManager {
    private String key;
    private int chiaveCifratura;
    private File filePassword = new File("filePassword.txt");
    File fileKey = new File("fileKey.txt");
    File fileChiave = new File("fileChiave.txt");

    public PasswordManager() throws IOException {
        if (fileChiave.exists()){
            FileReader reader = new FileReader("fileChiave.txt");
            String chiave = "";
            int n;
            while ((n=reader.read())!=-1){
                chiave += (char)n;
            }
            reader.close();
            chiaveCifratura = Integer.parseInt(chiave);
        }else{
            FileWriter writer = new FileWriter("fileChiave.txt");
            chiaveCifratura= (int)(Math.random()*15+1);
            writer.write(String.valueOf(chiaveCifratura));
            writer.close();
        }

    }

    private String cifra(String testo){
        String risultato = "";

        for (int i = 0; i < testo.length(); i++) {
            char c = testo.charAt(i);

            if (c >= 'a' && c <= 'z') {
                char cifrata = (char) ((c - 'a' + chiaveCifratura) % 26 + 'a');
                risultato += cifrata;
            } else if (c >= 'A' && c <= 'Z') {
                char cifrata = (char) ((c - 'A' + chiaveCifratura) % 26 + 'A');
                risultato += cifrata;
            } else {
                risultato += c;
            }
        }

        return risultato;
    }

    private String decifra(String testo){
        String risultato = "";

        for (int i = 0; i < testo.length(); i++) {
            char c = testo.charAt(i);

            if (c >= 'a' && c <= 'z') {
                char decifrata = (char) ((c - 'a' - chiaveCifratura + 26) % 26 + 'a');
                risultato += decifrata;
            } else if (c >= 'A' && c <= 'Z') {
                char decifrata = (char) ((c - 'A' - chiaveCifratura + 26) % 26 + 'A');
                risultato += decifrata;
            } else {
                risultato += c;
            }
        }

        return risultato;
    }

    public void aggiungiPassword(String nomeUtente, String password,String servizio) throws IOException {
        String passwordCifrata = cifra(password);
        FileWriter writer = new FileWriter("filePassword.txt",true);
        writer.append(nomeUtente+";"+passwordCifrata+";"+servizio+"\n");
        writer.close();
    }

    public void rimuoviPassword(String nomeUtente, String password,String servizio) throws IOException {
        String passwordCifrata = cifra(password);
        String contenuto = new String(Files.readAllBytes(Paths.get("filePassword.txt")));
        contenuto = contenuto.replace(nomeUtente+";"+passwordCifrata+";"+servizio+"\n","");
        FileWriter writer = new FileWriter("filePassword.txt");
        writer.write(contenuto);
        writer.close();
    }

    public boolean verificaChiave(String chiave) throws IOException{
        BufferedReader reader = new BufferedReader(new FileReader("fileKey.txt"));
        key = reader.readLine();
        reader.close();
        if (chiave.equals(key)){
            return true;
        }else{
            return false;
        }
    }

    public void creaKeyAccesso(String key) throws IOException{
        this.key = key;
        FileWriter writer = new FileWriter("fileKey.txt");
        writer.write(key);
        writer.close();
    }

    public String toString() {
        BufferedReader reader = null;
        String s = "";
        try {
            reader = new BufferedReader(new FileReader("filePassword.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        String riga;
        s += String.format("%-60s %-60s %-65s\n", "NOME UTENTE", "PASSWORD", "SERVIZIO");
        while (true){
            try {
                if (!((riga = reader.readLine())!= null)) break;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            String[] parti = riga.split(";");
            if (parti.length == 3) {
                parti[1] = decifra(parti[1]);
                s += String.format("%-60s %-60s %-65s\n", parti[0], parti[1], parti[2]);
            }
        }
        try {
            reader.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return s;
    }

    public boolean keyCreata() throws IOException {
        return new File("fileKey.txt").length() > 0;
    }

}

package com.example.capolavorov2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CreaCompitoController {
    private ToDoList toDoList = DatiCondivisi.getToDoList();
    private Stage stage;
    @FXML
    private TextField newCompitoNomeField;
    @FXML
    private TextField newCompitoDescrizioneField;
    @FXML
    private DatePicker newCompitoDataDatePicker;
    @FXML
    private ChoiceBox<String> newPrioritaCompitoChoiceBox;
    @FXML
    private Label statusNewCompitoLabel;
    private String[] priorita = {"Bassa","Media","Alta"};

    public CreaCompitoController() throws IOException {
    }

    @FXML
    public void initialize(){
        newPrioritaCompitoChoiceBox.getItems().addAll(priorita);
        statusNewCompitoLabel.setOpacity(0);
        newPrioritaCompitoChoiceBox.setValue("Bassa");
        newCompitoDataDatePicker.setValue(LocalDate.now());
    }
    @FXML
    public void switchMenu(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/capolavorov2/mainMenu.fxml"));
        Pane newScene = loader.load();
        Scene scene = new Scene(newScene);
        Stage stage = (Stage)((javafx.scene.Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }
    @FXML
    public void creaPassword(ActionEvent actionEvent) throws IOException{
        String nome = newCompitoNomeField.getText();
        String descrizione = newCompitoDescrizioneField.getText();
        LocalDate dataSelezionata = newCompitoDataDatePicker.getValue();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String dataScadenzaString = dataSelezionata.format(formatter);
        String priorita = newPrioritaCompitoChoiceBox.getValue();
        if (nome.equals("")||descrizione.equals("")||dataScadenzaString.equals("")||priorita.equals("")){
            statusNewCompitoLabel.setText("STATUS: Completare tutti i campi");
            statusNewCompitoLabel.setStyle("-fx-text-fill: red");
            statusNewCompitoLabel.setOpacity(100);
        }else{
            Compito compito = new Compito(nome,descrizione,dataScadenzaString,priorita);
            toDoList.aggiungiCompito(compito);
            statusNewCompitoLabel.setText("STATUS: Compito creato con successo");
            statusNewCompitoLabel.setStyle("-fx-text-fill: green");
            statusNewCompitoLabel.setOpacity(100);
            newCompitoDescrizioneField.setText("");
            newCompitoNomeField.setText("");
            newPrioritaCompitoChoiceBox.setValue("Bassa");
            newCompitoDataDatePicker.setValue(LocalDate.now());
        }

    }
}
